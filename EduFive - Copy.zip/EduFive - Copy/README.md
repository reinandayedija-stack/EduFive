# EduFive - Web Manajemen Tugas Mahasiswa

Prototype project akhir. Ditulis dengan **Python murni** (tanpa library tambahan) + HTML/CSS/JavaScript untuk tampilan.

## Cara menjalankan
1. Pastikan Python 3.8+ terpasang.
2. Taruh `app.py`, `logika.py`, dan `index.html` dalam satu folder.
3. Jalankan di terminal:
   ```
   python app.py
   ```
4. Buka browser ke http://localhost:8000

Port lain: `python app.py 5000`. Tombol **Reset Demo** di pojok kanan atas mengembalikan data contoh (berguna sebelum presentasi).

## Fitur
- Tambah tugas (judul, mata kuliah, deadline, prioritas, catatan)
- Jadwal perkuliahan mingguan
- Pengingat deadline (terlambat / mendesak / dekat) berupa notifikasi: pop-up di web + notifikasi browser (klik tombol "Aktifkan Notifikasi"; hanya muncul saat tab EduFive terbuka)
- Status pengerjaan (Belum / Sedang / Selesai) + progres

## Peta 7 materi wajib
| Poin | Materi | Letak di kode |
|---|---|---|
| a | Tipe data & Variable | Konstanta di `logika.py` (str, int, float, bool, None, dict) |
| b | String, Bilangan & Operator | `bersihkan_teks`, `format_sisa_hari`, `ringkasan` |
| c | Seleksi kondisi | `tentukan_level`, `format_sisa_hari`, `validasi_tugas` |
| d | Perulangan | `for` di `ringkasan`/`ambil_pengingat`, `while` di `buat_id_baru` |
| e | List dan Tuple | Tuple `HARI`, `STATUS_VALID`; list tugas & jadwal |
| f | Fungsi | Semua fungsi di `logika.py` (default param, `*args`, `return`, `lambda`) |
| g | Modul & Eksepsi | `import json/os/datetime`, modul `logika`, kelas `DataTidakValid`, `try/except` |

- Deadline tugas memakai tanggal **dan jam** (kosong = 23:59)
- Mata kuliah di form tugas berupa pilihan (dropdown) dari `DAFTAR_MATKUL` di `logika.py`
- Notifikasi harian pada jam pilihan di tab Pengingat (tombol "Tes notifikasi sekarang" untuk demo)

Data tersimpan otomatis di `data.json`.
