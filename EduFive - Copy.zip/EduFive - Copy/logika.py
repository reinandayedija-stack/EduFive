"""
logika.py - Modul logika EduFive (manajemen tugas mahasiswa)

Peta materi project (7 poin wajib):
  a. Tipe data & Variable      -> bagian "KONSTANTA & VARIABEL" di bawah
  b. String, Bilangan & Operator -> bersihkan_teks, format_sisa_hari, ringkasan
  c. Seleksi kondisi           -> tentukan_level, format_sisa_hari, validasi_*
  d. Perulangan                -> buat_id_baru (while), ringkasan/ambil_pengingat (for)
  e. List dan Tuple            -> HARI, STATUS_VALID (tuple); daftar tugas/jadwal (list)
  f. Fungsi                    -> seluruh fungsi di file ini (parameter default, *args, return)
  g. Modul & Eksepsi           -> import json/os/datetime, modul ini sendiri, DataTidakValid
"""

# ============ (g) MODUL: mengimpor modul bawaan Python ============
import json
import os
from datetime import date, datetime, timedelta

# ============ (a) TIPE DATA & VARIABLE: KONSTANTA & VARIABEL ============
NAMA_APLIKASI = "EduFive"          # str
VERSI = 1.0                        # float
BATAS_PENGINGAT_HARI = 3           # int
MODE_DEMO = True                   # bool
CATATAN_KOSONG = None              # NoneType
FILE_DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.json")

# ============ (e) TUPLE: data tetap yang tidak boleh berubah ============
HARI = ("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
STATUS_VALID = ("Belum Dikerjakan", "Sedang Dikerjakan", "Selesai")
PRIORITAS_VALID = ("Rendah", "Sedang", "Tinggi")

# Pilihan mata kuliah (dropdown di form tambah tugas)
DAFTAR_MATKUL = (
    "Entrepreneurship",
    "Dasar Pemrograman",
    "Bahasa Inggris 1",
    "Pendidikan Pancasila",
    "Pengantar Teknologi Informasi dan Komunikasi",
    "Logika dan Algoritma",
)
JAM_DEFAULT = "23:59"          # jam deadline bila tidak diisi
JAM_NOTIF_DEFAULT = "07:00"    # jam notifikasi harian bawaan

# dict: status -> bobot progres (%)
BOBOT_PROGRES = {"Belum Dikerjakan": 0, "Sedang Dikerjakan": 50, "Selesai": 100}


# ============ (g) EKSEPSI: kelas eksepsi buatan sendiri ============
class DataTidakValid(Exception):
    """Dilempar saat input pengguna tidak sesuai aturan."""

    def __init__(self, pesan, field=None):
        super().__init__(pesan)
        self.field = field


# ============ (f) FUNGSI + (b) STRING ============
def bersihkan_teks(teks):
    """Hapus spasi berlebih di awal, akhir, dan tengah teks."""
    if not isinstance(teks, str):
        return ""
    return " ".join(teks.split())


def gabung_catatan(*bagian, pemisah=" • "):
    """Fungsi dengan *args dan parameter default: gabungkan beberapa teks."""
    terisi = [bersihkan_teks(b) for b in bagian if bersihkan_teks(b)]
    return pemisah.join(terisi)


def parse_tanggal(teks):
    """Ubah 'YYYY-MM-DD' menjadi objek date. Gagal -> DataTidakValid."""
    try:
        return datetime.strptime(teks, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        raise DataTidakValid("Format tanggal harus YYYY-MM-DD", "deadline")


def validasi_jam(teks, field="jam"):
    """Pastikan format HH:MM, kembalikan dalam bentuk baku (07:05)."""
    try:
        return datetime.strptime(teks, "%H:%M").strftime("%H:%M")
    except (ValueError, TypeError):
        raise DataTidakValid("Format jam harus HH:MM", field)


def hitung_sisa_hari(deadline_str, hari_ini=None):
    """Hitung selisih hari antara hari ini dan deadline (bilangan bulat)."""
    hari_ini = hari_ini or date.today()
    return (parse_tanggal(deadline_str) - hari_ini).days


def hitung_sisa_menit(deadline_str, jam_str=JAM_DEFAULT, sekarang=None):
    """Selisih menit antara sekarang dan deadline (tanggal + jam). Negatif = lewat."""
    sekarang = sekarang or datetime.now()
    batas = datetime.combine(parse_tanggal(deadline_str),
                             datetime.strptime(jam_str, "%H:%M").time())
    return int((batas - sekarang).total_seconds() // 60)


def format_durasi(menit):
    """Ubah menit menjadi teks: '2 jam 5 menit', '45 menit', '3 hari'."""
    if menit >= 1440:
        return f"{menit // 1440} hari"
    jam, sisa = divmod(menit, 60)
    if jam and sisa:
        return f"{jam} jam {sisa} menit"
    if jam:
        return f"{jam} jam"
    return f"{sisa} menit"


# ============ (b) OPERATOR + (c) SELEKSI KONDISI ============
def format_sisa_hari(sisa):
    """Ubah angka sisa hari menjadi teks yang ramah dibaca."""
    if sisa < 0:
        return f"Terlambat {abs(sisa)} hari"
    elif sisa == 0:
        return "Hari ini!"
    elif sisa == 1:
        return "Besok"
    elif sisa < 7:
        return f"{sisa} hari lagi"
    else:
        minggu = sisa // 7      # operator pembagian bulat
        hari = sisa % 7         # operator modulus
        if hari:
            return f"{minggu} minggu {hari} hari lagi"
        return f"{minggu} minggu lagi"


def tentukan_level(sisa, status, sisa_menit=None):
    """Tentukan tingkat urgensi tugas dengan if / elif / else."""
    if status == "Selesai":
        return "selesai"
    if sisa < 0 or (sisa_menit is not None and sisa_menit < 0):
        return "terlambat"
    elif sisa <= 1:
        return "mendesak"
    elif sisa <= BATAS_PENGINGAT_HARI:
        return "dekat"
    else:
        return "aman"


# ============ (f) FUNGSI VALIDASI + (g) EKSEPSI ============
def validasi_tugas(data):
    """Periksa & bersihkan data tugas dari form. Salah -> DataTidakValid."""
    judul = bersihkan_teks(data.get("judul", ""))
    matkul = bersihkan_teks(data.get("matkul", ""))
    catatan = bersihkan_teks(data.get("catatan", ""))
    prioritas = data.get("prioritas", "Sedang")
    status = data.get("status", "Belum Dikerjakan")
    deadline = data.get("deadline", "")

    if len(judul) < 3:
        raise DataTidakValid("Judul tugas minimal 3 karakter", "judul")
    if not matkul:
        raise DataTidakValid("Mata kuliah wajib diisi", "matkul")
    if matkul not in DAFTAR_MATKUL:
        raise DataTidakValid("Pilih mata kuliah dari daftar", "matkul")
    parse_tanggal(deadline)  # akan melempar eksepsi jika format salah
    jam = validasi_jam(bersihkan_teks(data.get("jam", "")) or JAM_DEFAULT, "jam")
    if prioritas not in PRIORITAS_VALID:
        raise DataTidakValid("Prioritas tidak dikenal", "prioritas")
    if status not in STATUS_VALID:
        raise DataTidakValid("Status tidak dikenal", "status")

    return {
        "judul": judul[:1].upper() + judul[1:],
        "matkul": matkul,
        "deadline": deadline,
        "jam": jam,
        "prioritas": prioritas,
        "status": status,
        "catatan": catatan,
    }


def validasi_jadwal(data):
    """Periksa data jadwal kuliah (hari + jam HH:MM)."""
    matkul = bersihkan_teks(data.get("matkul", ""))
    hari = bersihkan_teks(data.get("hari", "")).capitalize()
    ruang = bersihkan_teks(data.get("ruang", ""))

    if not matkul:
        raise DataTidakValid("Nama mata kuliah wajib diisi", "matkul")
    if hari not in HARI:
        raise DataTidakValid("Hari tidak valid", "hari")
    try:
        mulai = datetime.strptime(data.get("jam_mulai", ""), "%H:%M")
        selesai = datetime.strptime(data.get("jam_selesai", ""), "%H:%M")
    except (ValueError, TypeError):
        raise DataTidakValid("Format jam harus HH:MM", "jam_mulai")
    if selesai <= mulai:
        raise DataTidakValid("Jam selesai harus setelah jam mulai", "jam_selesai")

    durasi = int((selesai - mulai).total_seconds() // 60)
    return {
        "matkul": matkul,
        "hari": hari,
        "jam_mulai": data["jam_mulai"],
        "jam_selesai": data["jam_selesai"],
        "ruang": ruang or "-",
        "durasi_menit": durasi,
    }


# ============ (d) PERULANGAN while & (e) LIST ============
def buat_id_baru(daftar):
    """Cari ID yang belum dipakai memakai perulangan while."""
    dipakai = {item["id"] for item in daftar}   # set comprehension
    kandidat = len(daftar) + 1
    while kandidat in dipakai:
        kandidat += 1
    return kandidat


def cari_item(daftar, id_item):
    """Cari item berdasarkan id dengan perulangan for."""
    for item in daftar:
        if item["id"] == id_item:
            return item
    raise DataTidakValid(f"Data dengan ID {id_item} tidak ditemukan")


def tambah_tugas(daftar, data):
    bersih = validasi_tugas(data)
    bersih["id"] = buat_id_baru(daftar)
    bersih["dibuat"] = date.today().isoformat()
    daftar.append(bersih)          # list.append
    return bersih


def ubah_status(daftar, id_item, status_baru):
    if status_baru not in STATUS_VALID:
        raise DataTidakValid("Status tidak dikenal", "status")
    tugas = cari_item(daftar, id_item)
    tugas["status"] = status_baru
    return tugas


def hapus_item(daftar, id_item):
    daftar.remove(cari_item(daftar, id_item))   # list.remove


def tambah_jadwal(daftar, data):
    bersih = validasi_jadwal(data)
    bersih["id"] = buat_id_baru(daftar)
    daftar.append(bersih)
    return bersih


def perkaya_tugas(tugas):
    """Tambahkan sisa hari/menit, label, level, dan progres ke data tugas."""
    jam = tugas.get("jam", JAM_DEFAULT)     # data lama tanpa jam -> 23:59
    sisa = hitung_sisa_hari(tugas["deadline"])
    menit = hitung_sisa_menit(tugas["deadline"], jam)
    hasil = dict(tugas)
    hasil["jam"] = jam
    hasil["sisa_hari"] = sisa
    hasil["sisa_menit"] = menit

    if tugas["status"] == "Selesai":
        hasil["label"] = "Selesai ✓"
    elif menit < 0:
        hasil["label"] = f"Terlambat {format_durasi(-menit)}"
    elif sisa == 0:
        hasil["label"] = f"Hari ini {jam} ({format_durasi(menit)} lagi)"
    else:
        hasil["label"] = f"{format_sisa_hari(sisa)}, {jam}"

    hasil["level"] = tentukan_level(sisa, tugas["status"], menit)
    hasil["progres"] = BOBOT_PROGRES[tugas["status"]]
    return hasil


def daftar_tugas_urut(daftar):
    """Urutkan: yang belum selesai dulu, lalu berdasarkan deadline terdekat."""
    diperkaya = [perkaya_tugas(t) for t in daftar]   # list comprehension
    return sorted(diperkaya, key=lambda t: (t["status"] == "Selesai", t["sisa_menit"]))


def ringkasan(daftar):
    """Hitung statistik dashboard dengan perulangan for dan operator aritmatika."""
    total = len(daftar)
    hitung = {s: 0 for s in STATUS_VALID}
    terlambat = 0
    total_progres = 0

    for tugas in daftar:
        hitung[tugas["status"]] += 1
        total_progres += BOBOT_PROGRES[tugas["status"]]
        if tugas["status"] != "Selesai" and hitung_sisa_menit(tugas["deadline"], tugas.get("jam", JAM_DEFAULT)) < 0:
            terlambat += 1

    persen_selesai = round(hitung["Selesai"] / total * 100) if total > 0 else 0
    rata_progres = round(total_progres / total) if total > 0 else 0
    return {
        "total": total,
        "belum": hitung["Belum Dikerjakan"],
        "sedang": hitung["Sedang Dikerjakan"],
        "selesai": hitung["Selesai"],
        "terlambat": terlambat,
        "persen_selesai": persen_selesai,
        "rata_progres": rata_progres,
    }


def buat_pesan_notifikasi(t):
    """Susun teks notifikasi sesuai tingkat urgensi tugas."""
    if t["level"] == "terlambat":
        ikon = "🚨"
    elif t["level"] == "mendesak":
        ikon = "⚠️"
    else:
        ikon = "⏰"
    return f"{ikon} {t['judul']} ({t['matkul']}) - {t['label']}"


def ambil_pengingat(daftar):
    """Kumpulkan tugas yang perlu diingatkan (terlambat / mendesak / dekat)."""
    hasil = []
    for tugas in daftar:
        t = perkaya_tugas(tugas)
        if t["level"] in ("terlambat", "mendesak", "dekat"):
            t["pesan"] = buat_pesan_notifikasi(t)
            hasil.append(t)
    hasil.sort(key=lambda t: t["sisa_menit"])
    return hasil


def jadwal_per_hari(jadwal):
    """Kelompokkan jadwal ke tiap hari (dict berisi list), urut jam mulai."""
    hasil = {h: [] for h in HARI}
    for j in jadwal:
        hasil[j["hari"]].append(j)
    for h in HARI:
        hasil[h].sort(key=lambda j: j["jam_mulai"])
    return hasil


def nama_hari_ini():
    return HARI[date.today().weekday()]   # indeks tuple


# ============ (g) MODUL & EKSEPSI: simpan / muat data dari file JSON ============
def data_awal():
    """Data contoh untuk demo; tanggal dibuat relatif terhadap hari ini."""
    def tgl(n):
        return (date.today() + timedelta(days=n)).isoformat()

    tugas = [
        {"id": 1, "judul": "Laporan praktikum Python", "matkul": "Dasar Pemrograman",
         "deadline": tgl(1), "jam": "10:00", "prioritas": "Tinggi", "status": "Sedang Dikerjakan",
         "catatan": "Lengkapi bagian fungsi & eksepsi", "dibuat": tgl(-5)},
        {"id": 2, "judul": "Resume bab 3", "matkul": "Bahasa Inggris 1",
         "deadline": tgl(-1), "jam": "23:59", "prioritas": "Sedang", "status": "Belum Dikerjakan",
         "catatan": "", "dibuat": tgl(-7)},
        {"id": 3, "judul": "Flowchart algoritma sorting", "matkul": "Logika dan Algoritma",
         "deadline": tgl(0), "jam": "23:59", "prioritas": "Tinggi", "status": "Belum Dikerjakan",
         "catatan": "Nomor 1-10", "dibuat": tgl(-3)},
        {"id": 4, "judul": "Proposal ide bisnis", "matkul": "Entrepreneurship",
         "deadline": tgl(4), "jam": "15:00", "prioritas": "Sedang", "status": "Sedang Dikerjakan",
         "catatan": "Minimal 5 halaman", "dibuat": tgl(-4)},
        {"id": 5, "judul": "Presentasi dampak TIK", "matkul": "Pengantar Teknologi Informasi dan Komunikasi",
         "deadline": tgl(9), "jam": "08:00", "prioritas": "Rendah", "status": "Belum Dikerjakan",
         "catatan": "", "dibuat": tgl(-1)},
        {"id": 6, "judul": "Esai Pancasila", "matkul": "Pendidikan Pancasila",
         "deadline": tgl(2), "jam": "23:59", "prioritas": "Rendah", "status": "Selesai",
         "catatan": "", "dibuat": tgl(-8)},
    ]
    jadwal = [
        {"id": 1, "matkul": "Dasar Pemrograman", "hari": "Senin", "jam_mulai": "08:00",
         "jam_selesai": "09:40", "ruang": "Lab Komputer 2", "durasi_menit": 100},
        {"id": 2, "matkul": "Pendidikan Pancasila", "hari": "Senin", "jam_mulai": "10:00",
         "jam_selesai": "11:40", "ruang": "R.101", "durasi_menit": 100},
        {"id": 3, "matkul": "Logika dan Algoritma", "hari": "Selasa", "jam_mulai": "10:00",
         "jam_selesai": "11:40", "ruang": "R.201", "durasi_menit": 100},
        {"id": 4, "matkul": "Pengantar Teknologi Informasi dan Komunikasi", "hari": "Rabu", "jam_mulai": "13:00",
         "jam_selesai": "14:40", "ruang": "R.305", "durasi_menit": 100},
        {"id": 5, "matkul": "Entrepreneurship", "hari": "Kamis", "jam_mulai": "08:00",
         "jam_selesai": "09:40", "ruang": "R.102", "durasi_menit": 100},
        {"id": 6, "matkul": "Bahasa Inggris 1", "hari": "Jumat", "jam_mulai": "09:00",
         "jam_selesai": "10:40", "ruang": "R.210", "durasi_menit": 100},
    ]
    return {"tugas": tugas, "jadwal": jadwal,
            "pengaturan": {"jam_notifikasi": JAM_NOTIF_DEFAULT}}


def muat_data():
    """Baca data.json; jika belum ada / rusak, pakai data contoh."""
    try:
        with open(FILE_DATA, "r", encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("tugas", [])
        data.setdefault("jadwal", [])
        data.setdefault("pengaturan", {}).setdefault("jam_notifikasi", JAM_NOTIF_DEFAULT)
        return data
    except FileNotFoundError:
        return data_awal()
    except json.JSONDecodeError:
        print("Peringatan: data.json rusak, memakai data contoh.")
        return data_awal()


def ubah_pengaturan(pengaturan, data):
    """Simpan jam notifikasi harian (HH:MM)."""
    pengaturan["jam_notifikasi"] = validasi_jam(data.get("jam_notifikasi"), "jam_notifikasi")
    return pengaturan


def simpan_data(data):
    with open(FILE_DATA, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
