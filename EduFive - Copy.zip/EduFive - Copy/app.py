"""
app.py - Server web EduFive (Python murni, tanpa library tambahan).

Jalankan:  python app.py        lalu buka  http://localhost:8000
"""
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

import logika  # modul buatan sendiri (materi: Modul)

FOLDER = os.path.dirname(os.path.abspath(__file__))
DATA = logika.muat_data()   # dict berisi list "tugas" dan "jadwal"


class Handler(BaseHTTPRequestHandler):
    # ---------- helper respons ----------
    def _kirim_json(self, kode, isi):
        badan = json.dumps(isi, ensure_ascii=False).encode("utf-8")
        self.send_response(kode)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(badan)))
        self.end_headers()
        self.wfile.write(badan)

    def _kirim_html(self):
        with open(os.path.join(FOLDER, "index.html"), "rb") as f:
            badan = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(badan)))
        self.end_headers()
        self.wfile.write(badan)

    def _baca_body(self):
        try:
            panjang = int(self.headers.get("Content-Length", 0))
            mentah = self.rfile.read(panjang) if panjang > 0 else b"{}"
            return json.loads(mentah.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise logika.DataTidakValid("Data yang dikirim tidak valid")

    # ---------- routing ----------
    def _tangani(self, metode):
        try:
            bagian = [b for b in urlparse(self.path).path.split("/") if b]
            if metode == "GET" and not bagian:
                return self._kirim_html()
            if not bagian or bagian[0] != "api":
                return self._kirim_json(404, {"error": "Halaman tidak ditemukan"})
            self._kirim_json(200, self._rute(metode, bagian[1:]))
        except logika.DataTidakValid as e:
            self._kirim_json(400, {"error": str(e), "field": e.field})
        except LookupError as e:
            self._kirim_json(404, {"error": str(e)})
        except ValueError:
            self._kirim_json(400, {"error": "ID harus berupa angka"})
        except Exception as e:  # jaring pengaman terakhir
            self._kirim_json(500, {"error": f"Kesalahan server: {e}"})

    def _rute(self, metode, bagian):
        sumber = bagian[0] if bagian else ""
        id_item = int(bagian[1]) if len(bagian) > 1 else None

        if sumber == "ringkasan" and metode == "GET":
            return {
                "ringkasan": logika.ringkasan(DATA["tugas"]),
                "hari_ini": logika.nama_hari_ini(),
                "nama_app": logika.NAMA_APLIKASI,
                "versi": logika.VERSI,
            }

        if sumber == "tugas":
            if metode == "GET" and id_item is None:
                return logika.daftar_tugas_urut(DATA["tugas"])
            if metode == "POST" and id_item is None:
                baru = logika.tambah_tugas(DATA["tugas"], self._baca_body())
                logika.simpan_data(DATA)
                return logika.perkaya_tugas(baru)
            if metode == "PUT" and id_item is not None:
                status = self._baca_body().get("status", "")
                ubah = logika.ubah_status(DATA["tugas"], id_item, status)
                logika.simpan_data(DATA)
                return logika.perkaya_tugas(ubah)
            if metode == "DELETE" and id_item is not None:
                logika.hapus_item(DATA["tugas"], id_item)
                logika.simpan_data(DATA)
                return {"ok": True}

        if sumber == "jadwal":
            if metode == "GET" and id_item is None:
                return {
                    "per_hari": logika.jadwal_per_hari(DATA["jadwal"]),
                    "hari_ini": logika.nama_hari_ini(),
                }
            if metode == "POST" and id_item is None:
                baru = logika.tambah_jadwal(DATA["jadwal"], self._baca_body())
                logika.simpan_data(DATA)
                return baru
            if metode == "DELETE" and id_item is not None:
                logika.hapus_item(DATA["jadwal"], id_item)
                logika.simpan_data(DATA)
                return {"ok": True}

        if sumber == "opsi" and metode == "GET":
            return {"matkul": list(logika.DAFTAR_MATKUL)}

        if sumber == "pengaturan":
            if metode == "GET":
                return DATA["pengaturan"]
            if metode == "PUT":
                logika.ubah_pengaturan(DATA["pengaturan"], self._baca_body())
                logika.simpan_data(DATA)
                return DATA["pengaturan"]

        if sumber == "pengingat" and metode == "GET":
            return logika.ambil_pengingat(DATA["tugas"])

        if sumber == "reset" and metode == "POST":
            DATA.clear()
            DATA.update(logika.data_awal())
            logika.simpan_data(DATA)
            return {"ok": True}

        raise LookupError("Endpoint tidak ditemukan")

    # ---------- metode HTTP ----------
    def do_GET(self):
        self._tangani("GET")

    def do_POST(self):
        self._tangani("POST")

    def do_PUT(self):
        self._tangani("PUT")

    def do_DELETE(self):
        self._tangani("DELETE")

    def log_message(self, format, *args):
        pass  # sunyikan log agar terminal bersih saat presentasi


def main(port=8000):
    server = HTTPServer(("0.0.0.0", port), Handler)
    print(f"{logika.NAMA_APLIKASI} v{logika.VERSI} berjalan di http://localhost:{port}")
    print("Tekan Ctrl+C untuk berhenti.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer dihentikan.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 8000)
